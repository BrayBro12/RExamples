# Scratch Work for Lab 7 Shiny App

library(tidyverse)
library(lubridate)

dat = read_csv("GPS_Well_Month_deidentified.csv") %>% 
  mutate(week_num = week(Date))

cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# Wellness Data by Position
well_position = dat %>%
  select(week_num, Position, Sleep_Quality:Desire_Motivation_to_Train) %>% 
  group_by(week_num, Position)

well_Centerback = well_position %>%
  filter(Position == 'Centerback') %>%
  pivot_longer(-c(week_num, Position), names_to = 'Metric', values_to = 'Values') %>%
  group_by(week_num, Metric, Position) %>%
  summarise_at(vars(Values), list(mean = ~ mean(., na.rm = T),
                                  lower = ~ quantile(.,probs = 0.025),
                                  upper = ~ quantile(.,probs = 0.975))) %>%
  select(-c(Position))

ggplot(well_Centerback, aes(x = week_num, y = mean)) +
  geom_line() +
  geom_point() +
  geom_errorbar(aes(ymin = lower, ymax = upper), width=.2, position=position_dodge()) +
  facet_wrap( ~ Metric) +
  xlab("") +
  ylab("") +
  ggtitle('Centerback Wellness Data')
  
unique(well_position$Position)

# GPS Data by Position
GPS_position = dat %>%
  select(week_num, Position, Meters_per_Min., PlayerLoad_per_Min., HSR_per_Min.) %>% 
  filter(complete.cases(.)) %>% 
  filter(PlayerLoad_per_Min. != '#DIV/0!') %>%
  mutate_at(vars(Meters_per_Min.:HSR_per_Min.), ~ as.numeric(.)) %>%
  group_by(week_num, Position)

GPS_Centerback = GPS_position %>%
  filter(Position == 'Centerback') %>%
  pivot_longer(-c(week_num, Position), names_to = 'Metric', values_to = 'Values') %>%
  filter(Values != 0) %>%
  group_by(week_num, Metric, Position) %>%
  summarise_at(vars(Values), list(mean = ~ mean(., na.rm = T),
                                  lower = ~ quantile(.,probs = 0.025),
                                  upper = ~ quantile(.,probs = 0.975))) %>%
  select(-c(Position))

ggplot(GPS_Centerback, aes(x = week_num, y = mean)) +
  geom_line() +
  geom_point() +
  geom_errorbar(aes(ymin = lower, ymax = upper), width=.2, position=position_dodge()) +
  facet_wrap( ~ Metric, scale = 'free_y') +
  xlab("") +
  ylab("") +
  ggtitle('Centerback GPS Data')
