# Brady Kempf
# 
# Using R Shiny to develop an app to display wellness and GPS data for a soccer team. 
# The data is organized by position over a five-week period, which can be selected using the drop-down
# list located in the upper-lefthand corner of the app.
#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

# Pre-processing steps
library(shiny)
library(tidyverse)
library(lubridate)
library(gridExtra)

dat = read_csv("GPS_Well_Month_deidentified.csv") %>% 
    mutate(week_num = week(Date))

cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

well_position = dat %>%
    select(week_num, Position, Sleep_Quality:Desire_Motivation_to_Train) %>% 
    group_by(week_num, Position)

GPS_position = dat %>%
    select(week_num, Position, Meters_per_Min., PlayerLoad_per_Min., HSR_per_Min.) %>% 
    filter(complete.cases(.)) %>% 
    filter(PlayerLoad_per_Min. != '#DIV/0!') %>%
    mutate_at(vars(Meters_per_Min.:HSR_per_Min.), ~ as.numeric(.)) %>%
    group_by(week_num, Position)


# Define UI for application that draws a histogram
ui <- fluidPage(

    # Application title
    titlePanel("Positional Player Wellness and GPS Data"),

    # Sidebar with a slider input for number of bins 
    sidebarLayout(
        sidebarPanel(
            selectInput("position",
                        "Position:",
                        unique(well_position$Position))
        ),

        # Show a plot of the generated distribution
        mainPanel(
           plotOutput("wellGPSPlot", height="800px")
        )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output) {
    
    # Positional Wellness Data
    well_dat <- reactive({
        
        well_dat = well_position %>%
            filter(Position == input$position) %>%
            pivot_longer(-c(week_num, Position), names_to = 'Metric', values_to = 'Values') %>%
            group_by(week_num, Metric, Position) %>%
            summarise_at(vars(Values), list(mean = ~ mean(., na.rm = T),
                                            lower = ~ quantile(.,probs = 0.025),
                                            upper = ~ quantile(.,probs = 0.975))) %>%
            select(-c(Position)) 
    })

    # Positional GPS Data
    GPS_dat <- reactive({
        
        GPS_dat = GPS_position %>%
            filter(Position == input$position) %>%
            pivot_longer(-c(week_num, Position), names_to = 'Metric', values_to = 'Values') %>%
            filter(Values != 0) %>%
            group_by(week_num, Metric, Position) %>%
            summarise_at(vars(Values), list(mean = ~ mean(., na.rm = T),
                                            lower = ~ quantile(.,probs = 0.025),
                                            upper = ~ quantile(.,probs = 0.975))) %>%
            select(-c(Position)) 
        
    })
    
    # Plotting Wellness and GPS stacked on top of each other
    output$wellGPSPlot <- renderPlot({
        
        p1 = ggplot(well_dat(), aes(x = week_num, y = mean)) +
            geom_line() +
            geom_point() +
            geom_errorbar(aes(ymin = lower, ymax = upper), width=.2, position=position_dodge()) +
            facet_wrap( ~ Metric) +
            xlab("") +
            ylab("") +
            ggtitle(paste0(input$position, ' Wellness Data'))
        
        p2 = ggplot(GPS_dat(), aes(x = week_num, y = mean)) +
            geom_line() +
            geom_point() +
            geom_errorbar(aes(ymin = lower, ymax = upper), width=.2, position=position_dodge()) +
            facet_wrap( ~ Metric, scale = 'free_y') +
            xlab("") +
            ylab("") +
            ggtitle(paste0(input$position, ' GPS Data'))
        
        grid.arrange(p1, p2, ncol=1)
    })
}

# Run the application 
shinyApp(ui = ui, server = server)
